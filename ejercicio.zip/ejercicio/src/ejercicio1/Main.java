package ejercicio1;

public class Main {

    public static void main(String[] args) {
        Micoche coche = new Micoche();

        coche.numeropuertas = 0;
        coche.incrementarpuerta();
        coche.incrementarpuerta();
        coche.incrementarpuerta();
        coche.incrementarpuerta();
    }
}
